package com.example.galaxystudy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.*;

/** Android text-selection PROCESS_TEXT action; never changes text in other apps. */
public class SelectionTranslateActivity extends Activity {
  private Translator translator;
  private TextView status;
  private String input;
  @Override public void onCreate(Bundle saved) {
    super.onCreate(saved);
    CharSequence selected=getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
    input=selected==null?"":selected.toString().trim();
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(28,24,28,20);
    TextView original=new TextView(this);original.setText("선택한 글자: "+input);original.setTextSize(16);layout.addView(original);
    Spinner spinner=new Spinner(this);String[] languages={"자동 감지 (영어/일본어)","영어 → 한국어","일본어 → 한국어"};
    ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,languages);spinner.setAdapter(adapter);layout.addView(spinner);
    status=new TextView(this);status.setText("번역 준비 중");status.setTextSize(19);status.setPadding(0,18,0,18);layout.addView(status);
    Button translate=new Button(this);translate.setText("번역하기 / 재시도");layout.addView(translate);
    translate.setOnClickListener(v->translate(spinner.getSelectedItemPosition()));
    setContentView(layout);
    if(input.isEmpty()){status.setText("선택된 글자가 없습니다. 다른 앱에서 글자를 길게 눌러 선택하세요.");translate.setEnabled(false);}
    else translate(0);
  }
  private void translate(int choice){
    if(translator!=null){translator.close();translator=null;}
    boolean japanese=choice==2 || (choice==0 && hasJapanese(input));
    String from=japanese?TranslateLanguage.JAPANESE:TranslateLanguage.ENGLISH;
    status.setText("번역 모델 준비 중… 첫 사용 시 Wi-Fi 다운로드가 필요합니다.");
    translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(TranslateLanguage.KOREAN).build());
    Translator active=translator;
    active.downloadModelIfNeeded(new DownloadConditions.Builder().build())
      .addOnSuccessListener(unused->{if(active!=translator)return;status.setText("번역 중…");active.translate(input)
        .addOnSuccessListener(result->{if(active==translator)status.setText(result);})
        .addOnFailureListener(e->{if(active==translator)status.setText("번역 실패: "+e.getMessage()+"\nWi-Fi 확인 후 재시도하세요.");});})
      .addOnFailureListener(e->{if(active==translator)status.setText("모델 다운로드 실패: "+e.getMessage()+"\n인터넷을 확인하고 재시도하세요.");});
  }
  private boolean hasJapanese(String s){for(int i=0;i<s.length();i++){char c=s.charAt(i);if((c>=0x3040&&c<=0x30ff)||(c>=0xff66&&c<=0xff9f))return true;}return false;}
  @Override protected void onDestroy(){if(translator!=null)translator.close();super.onDestroy();}
}
