package com.example.galaxystudy;

import android.app.*;
import android.content.*;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
 private static final int CAPTURE = 101;
 private MediaProjectionManager manager;
 @Override public void onCreate(Bundle b) { super.onCreate(b);
  manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
  LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(32,45,32,24);
  TextView title=new TextView(this); title.setText("학습 화면 번역 도우미"); title.setTextSize(24); root.addView(title);
  TextView description=new TextView(this); description.setText("일반 학습용 도구입니다. 화면 공유를 시작해도 자동 번역하지 않습니다. 다른 앱 위의 [번역 영역 선택] 버튼을 누른 다음 원하는 문장을 드래그하세요. 선택 영역의 영어 또는 일본어 문장을 한국어로 번역해 위쪽에 표시합니다. 첫 사용 시 모델 다운로드가 필요합니다. 일반 학습에만 사용하세요."); description.setTextSize(16); root.addView(description);
  Button start=new Button(this); start.setText("영역 번역 시작"); root.addView(start);
  Button stop=new Button(this); stop.setText("중지"); root.addView(stop);
  start.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){ Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())); startActivity(i); Toast.makeText(this,"다른 앱 위에 표시 권한을 허용한 후 다시 시작하세요",Toast.LENGTH_LONG).show(); return; }
   startActivityForResult(manager.createScreenCaptureIntent(),CAPTURE);
  });
  stop.setOnClickListener(v->stopService(new Intent(this,CaptureService.class)));
  setContentView(root);
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==CAPTURE&&result==RESULT_OK&&data!=null){Intent i=new Intent(this,CaptureService.class);i.putExtra("result",result);i.putExtra("data",data);startForegroundService(i);Toast.makeText(this,"영역 선택 버튼을 누르면 번역할 수 있습니다",Toast.LENGTH_SHORT).show();}}
}
