package com.example.galaxystudy;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.nl.translate.*;
import java.nio.ByteBuffer;
import java.util.*;

/** Only captures after the user explicitly drags a region. No automatic scanning. */
public class CaptureService extends Service {
 private final Handler handler=new Handler(Looper.getMainLooper());
 private WindowManager wm;
 private View bubble, selection, resultPanel;
 private SelectionView selectionView;
 private MediaProjection projection;
 private android.hardware.display.VirtualDisplay virtualDisplay;
 private ImageReader reader;
 private TextRecognizer englishOcr, japaneseOcr;
 private Translator englishTranslator, japaneseTranslator;
 private int width,height,density;
 private boolean busy=false;
 private int requestId=0;
 private Rect selected;
 private String languageMode="auto";
 private boolean naturalMode=true;
 private boolean diagnosticMode=true;
 private String lastDiagnostic="진단 기록 없음";
 private long captureStartNanos=0L;
 private int frameWidth=0,frameHeight=0;
 private String safeError(Exception e){return e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());}

 @Override public void onCreate(){super.onCreate();
  NotificationChannel channel=new NotificationChannel("study","학습 영역 번역",NotificationManager.IMPORTANCE_LOW);
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(metrics);
  width=metrics.widthPixels;height=metrics.heightPixels;density=metrics.densityDpi;
  englishOcr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  japaneseOcr=TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  Notification n=new Notification.Builder(this,"study").setContentTitle("학습 영역 번역 준비됨")
   .setContentText("번역 버튼을 누른 뒤 영역을 드래그하세요")
   .setSmallIcon(android.R.drawable.ic_menu_crop)
   .setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE)).build();
  if(Build.VERSION.SDK_INT>=29)startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(1,n);
  if(intent==null||!intent.hasExtra("data")){stopSelf();return START_NOT_STICKY;}
  MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
  Intent data=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra("data",Intent.class):intent.getParcelableExtra("data");
  projection=manager.getMediaProjection(intent.getIntExtra("result",-1),data);
  if(projection==null){stopSelf();return START_NOT_STICKY;}
  projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
  reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
  virtualDisplay=projection.createVirtualDisplay("region-translation",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
  showBubble();return START_NOT_STICKY;
 }
 private WindowManager.LayoutParams params(int w,int h,int flags){
  return new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
 }
 private void showBubble(){
  LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.VERTICAL);
  Button select=new Button(this);select.setText("번역 영역 선택");select.setAllCaps(false);bar.addView(select);
  Button mode=new Button(this);mode.setAllCaps(false);mode.setText("번역: 자연스럽게");bar.addView(mode);
  WindowManager.LayoutParams p=params(-2,-2,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
  p.gravity=Gravity.TOP|Gravity.END;p.y=height/5;
  wm.addView(bar,p);bubble=bar;
  select.setOnClickListener(v->startSelection());
  Button diag=new Button(this);diag.setAllCaps(false);diag.setText("진단: 켜짐");bar.addView(diag);
  diag.setOnClickListener(v->{diagnosticMode=!diagnosticMode;diag.setText(diagnosticMode?"진단: 켜짐":"진단: 꺼짐");
    Toast.makeText(this,"최근 진단: "+lastDiagnostic,Toast.LENGTH_LONG).show();});
  mode.setOnClickListener(v->{naturalMode=!naturalMode;mode.setText(naturalMode?"번역: 자연스럽게":"번역: 직역");
    Toast.makeText(this,naturalMode?"문단 전체를 자연스럽게 번역합니다":"인식한 줄별로 번역합니다",Toast.LENGTH_SHORT).show();});
  select.setOnLongClickListener(v->{stopSelf();return true;});
 }
 private void startSelection(){
  if(busy){Toast.makeText(this,"이전 번역을 처리 중입니다",Toast.LENGTH_SHORT).show();return;}
  removeResult();
  if(bubble!=null)bubble.setVisibility(View.GONE);
  selectionView=new SelectionView(this);
  WindowManager.LayoutParams p=params(-1,-1,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
  p.gravity=Gravity.TOP|Gravity.START;
  wm.addView(selectionView,p);selection=selectionView;
 }
 private class SelectionView extends View {
  Paint paint=new Paint(3);float x0,y0,x1,y1;boolean dragging=false;
  SelectionView(Context c){super(c);setBackgroundColor(0x44000000);}
  @Override protected void onDraw(Canvas c){super.onDraw(c);
   if(!dragging)return;
   RectF r=new RectF(Math.min(x0,x1),Math.min(y0,y1),Math.max(x0,x1),Math.max(y0,y1));
   paint.setColor(0x443399FF);paint.setStyle(Paint.Style.FILL);c.drawRect(r,paint);
   paint.setColor(0xFF1688FF);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(5);c.drawRect(r,paint);paint.setStyle(Paint.Style.FILL);
  }
  @Override public boolean onTouchEvent(android.view.MotionEvent e){
   switch(e.getActionMasked()){
    case MotionEvent.ACTION_DOWN:x0=x1=e.getX();y0=y1=e.getY();dragging=true;invalidate();return true;
    case MotionEvent.ACTION_MOVE:x1=e.getX();y1=e.getY();invalidate();return true;
    case MotionEvent.ACTION_UP:
     x1=e.getX();y1=e.getY();
     int[] screenOffset=new int[2];getLocationOnScreen(screenOffset);
     Rect region=new Rect((int)Math.min(x0,x1)+screenOffset[0],(int)Math.min(y0,y1)+screenOffset[1],
      (int)Math.max(x0,x1)+screenOffset[0],(int)Math.max(y0,y1)+screenOffset[1]);
     finishSelection(region);return true;
    case MotionEvent.ACTION_CANCEL:cancelSelection();return true;
   }return true;
  }
 }
 private void cancelSelection(){removeSelection();if(bubble!=null)bubble.setVisibility(View.VISIBLE);}
 private void removeSelection(){if(selection!=null){wm.removeView(selection);selection=null;selectionView=null;}}
 private void finishSelection(Rect region){
  removeSelection();if(bubble!=null)bubble.setVisibility(View.GONE);
  region.intersect(0,0,width,height);
  if(region.width()<25||region.height()<20){showResult("영역이 너무 작습니다. 다시 드래그하세요.",region);return;}
  selected=region;busy=true;final int token=++requestId;
  captureStartNanos=System.nanoTime();
  lastDiagnostic="선택="+region.toShortString()+" / 디스플레이="+width+"x"+height;
  // Keep all overlays hidden while taking the screenshot, so OCR never reads its own status text.
  removeResult();
  // Allow overlay changes to disappear from the screen-capture stream.
  handler.postDelayed(()->captureRegion(token,0),450);
 }
 private void captureRegion(int token,int attempt){
  if(token!=requestId||reader==null)return;
  Image image=null;
  try{
   image=reader.acquireLatestImage();
   if(image==null){retryCapture(token,attempt,"새 캡처 프레임 없음");return;}
   long timestamp=image.getTimestamp();
   if(timestamp>0 && timestamp<captureStartNanos && attempt<16){image.close();retryCapture(token,attempt,"이전 프레임 대기");return;}
   int imgW=image.getWidth(),imgH=image.getHeight();
   frameWidth=imgW;frameHeight=imgH;
   Image.Plane plane=image.getPlanes()[0];ByteBuffer buffer=plane.getBuffer();buffer.rewind();
   int rowStride=plane.getRowStride(),pixelStride=plane.getPixelStride();
   if(pixelStride!=4 || rowStride<imgW*4)throw new IllegalStateException("지원하지 않는 화면 픽셀 형식: "+pixelStride);
   int paddedW=rowStride/pixelStride;
   Bitmap padded=Bitmap.createBitmap(paddedW,imgH,Bitmap.Config.ARGB_8888);
   padded.copyPixelsFromBuffer(buffer);
   image.close();image=null;
   // Selection coordinates are in physical screen pixels; rescale to actual capture dimensions.
   Rect cropRect=new Rect(Math.round(selected.left*(float)imgW/width),Math.round(selected.top*(float)imgH/height),
    Math.round(selected.right*(float)imgW/width),Math.round(selected.bottom*(float)imgH/height));
   cropRect.intersect(0,0,imgW,imgH);
   if(cropRect.width()<10||cropRect.height()<10){padded.recycle();fail("캡처 좌표가 잘못되었습니다. "+cropRect.toShortString(),token);return;}
   Bitmap crop=Bitmap.createBitmap(padded,cropRect.left,cropRect.top,cropRect.width(),cropRect.height());
   padded.recycle();
   lastDiagnostic="화면="+width+"x"+height+", 캡처="+imgW+"x"+imgH+", 선택="+selected.toShortString()+", 자름="+cropRect.toShortString()+", 시도="+(attempt+1);
   // Scale only small regions; do not downsample larger crops.
   if(crop.getWidth()<1100){int target=Math.min(2200,crop.getWidth()*2);
    int targetHeight=Math.max(1,(int)((long)crop.getHeight()*target/crop.getWidth()));
    Bitmap enlarged=Bitmap.createScaledBitmap(crop,target,targetHeight,true);
    if(enlarged!=crop){crop.recycle();crop=enlarged;}}
   recognize(crop,token);
  }catch(Exception e){if(image!=null)image.close();fail("화면 처리 오류: "+safeError(e),token);}
 }
 private void retryCapture(int token,int attempt,String reason){
  if(attempt<16)handler.postDelayed(()->captureRegion(token,attempt+1),220);
  else fail("화면 캡처 실패 ("+reason+"). 화면 공유 권한을 다시 허용해 주세요.",token);
 }
 private void recognize(Bitmap crop,int token){
  InputImage input=InputImage.fromBitmap(crop,0);
  englishOcr.process(input).addOnSuccessListener(en->{
   japaneseOcr.process(input).addOnSuccessListener(ja->{
    crop.recycle();if(token!=requestId)return;
    String english=orderedText(en),japanese=orderedText(ja);
    lastDiagnostic += ", 영어="+english.length()+"자, 일본어="+japanese.length()+"자";
    boolean jp=containsJapanese(japanese) && (!containsJapanese(english) || japanese.length()>=english.length()/2);
    String source=jp?japanese:english;
    if(source.trim().isEmpty())source=jp?english:japanese;
    if(source.trim().isEmpty()){
     fail("선택한 영역에서 글자를 찾지 못했습니다.\n"+(diagnosticMode?lastDiagnostic+"\n":"")+
      "휴대폰 화면 공유 시 '전체 화면'을 선택했는지 확인하세요.",token);return;}
    translate(source,jp,token);
   }).addOnFailureListener(e->{crop.recycle();fail("일본어 문자 인식 오류: "+e.getMessage(),token);});
  }).addOnFailureListener(e->{crop.recycle();fail("영어 문자 인식 오류: "+e.getMessage(),token);});
 }
 private String orderedText(Text result){
  ArrayList<Text.Line> lines=new ArrayList<>();
  for(Text.TextBlock block:result.getTextBlocks())lines.addAll(block.getLines());
  Collections.sort(lines,(a,b)->{Rect x=a.getBoundingBox(),y=b.getBoundingBox();if(x==null||y==null)return 0;
   if(Math.abs(x.centerY()-y.centerY())<Math.max(x.height(),y.height())/2)return Integer.compare(x.left,y.left);
   return Integer.compare(x.top,y.top);
  });
  StringBuilder sb=new StringBuilder();for(Text.Line line:lines){if(sb.length()>0)sb.append("\n");sb.append(line.getText().trim());}
  return sb.toString();
 }
 private boolean containsJapanese(String s){for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c>=0x3040&&c<=0x30ff||c>=0xff66&&c<=0xff9f)return true;}return false;}
 private String cleanSource(String text){
  // Remove standalone reference numbers, e.g. [7], [5][8], that disrupt translation.
  return text.replaceAll("\\[(?:[0-9]+)\\]", " ").replaceAll("[ \t]+", " ").trim();
 }
 private void translate(String text,boolean japanese,int token){
  final boolean useNatural=naturalMode;
  final String clean=cleanSource(text);
  showResult("번역 모델 준비 중…",selected);
  Translator translator=japanese?japaneseTranslator:englishTranslator;
  if(translator==null){translator=Translation.getClient(new TranslatorOptions.Builder()
   .setSourceLanguage(japanese?TranslateLanguage.JAPANESE:TranslateLanguage.ENGLISH)
   .setTargetLanguage(TranslateLanguage.KOREAN).build());
   if(japanese)japaneseTranslator=translator;else englishTranslator=translator;
  }
  final Translator active=translator;
  active.downloadModelIfNeeded().addOnSuccessListener(v->{
   if(token!=requestId)return;
   showResult(useNatural?"문단 전체 번역 중…":"줄별 직역 중…",selected);
   if(useNatural){
    // Whole paragraph gives the model more context than independent words/lines.
    String paragraph=clean.replace('\n',' ').replaceAll(" +"," ");
    active.translate(paragraph).addOnSuccessListener(korean->{if(token==requestId){busy=false;showResult(korean,selected);}})
     .addOnFailureListener(e->fail("번역 실패: "+e.getMessage(),token));
   }else{
    String[] lines=clean.split("\\n+");
    ArrayList<String> chunks=new ArrayList<>();for(String line:lines)if(!line.trim().isEmpty())chunks.add(line.trim());
    translateLines(active,chunks,0,new StringBuilder(),token);
   }
  }).addOnFailureListener(e->fail("번역 모델 다운로드 실패: "+e.getMessage()+"\nWi-Fi를 확인하세요.",token));
 }
 private void translateLines(Translator active,ArrayList<String> lines,int index,StringBuilder result,int token){
  if(token!=requestId)return;
  if(index>=lines.size()){busy=false;showResult(result.toString().trim(),selected);return;}
  active.translate(lines.get(index)).addOnSuccessListener(out->{
   if(result.length()>0)result.append("\n");result.append(out);
   translateLines(active,lines,index+1,result,token);
  }).addOnFailureListener(e->fail("줄별 번역 실패: "+e.getMessage(),token));
 }
 private void fail(String message,int token){if(token==requestId){busy=false;
  android.util.Log.e("GalaxyTranslatorV5",message+" / "+lastDiagnostic);
  showResult(message+(diagnosticMode?"\n[진단] "+lastDiagnostic:""),selected);}}
 private void removeResult(){if(resultPanel!=null){wm.removeView(resultPanel);resultPanel=null;}}
 private void showResult(String message,Rect region){handler.post(()->{
  if(bubble!=null)bubble.setVisibility(View.VISIBLE);
  removeResult();
  LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(18,12,18,8);panel.setBackgroundColor(0xF5FFFFFF);
  TextView text=new TextView(this);text.setText(message);text.setTextColor(0xFF17243B);text.setTextSize(16);panel.addView(text);
  Button close=new Button(this);close.setText("닫기");panel.addView(close);
  int popupWidth=Math.min(width-32,(int)(360*getResources().getDisplayMetrics().density));
  WindowManager.LayoutParams p=params(popupWidth,-2,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
  p.gravity=Gravity.TOP|Gravity.START;p.x=Math.max(0,Math.min(width-popupWidth,region.left));
  p.y=region.top>180?Math.max(0,region.top-175):Math.min(height-220,region.bottom+15);
  wm.addView(panel,p);resultPanel=panel;
  close.setOnClickListener(v->removeResult());
 });}
 @Override public void onDestroy(){++requestId;removeResult();removeSelection();if(bubble!=null)wm.removeView(bubble);
  if(virtualDisplay!=null)virtualDisplay.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();
  if(englishOcr!=null)englishOcr.close();if(japaneseOcr!=null)japaneseOcr.close();
  if(englishTranslator!=null)englishTranslator.close();if(japaneseTranslator!=null)japaneseTranslator.close();super.onDestroy();}
 @Override public IBinder onBind(Intent intent){return null;}
}
