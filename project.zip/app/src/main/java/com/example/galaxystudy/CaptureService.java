package com.example.galaxystudy;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.nl.translate.*;
import java.nio.ByteBuffer;
import java.util.*;

/** Only captures after the user explicitly drags a region. No automatic scanning. */
public class CaptureService extends Service {
 private final Handler handler=new Handler(Looper.getMainLooper());
 private WindowManager wm;
 private View bubble, selection, resultPanel;
 private SelectionView selectionView;
 private MediaProjection projection;
 private android.hardware.display.VirtualDisplay virtualDisplay;
 private ImageReader reader;
 private TextRecognizer englishOcr, japaneseOcr;
 private Translator englishTranslator, japaneseTranslator;
 private int width,height,density;
 private boolean busy=false;
 private int requestId=0;
 private Rect selected;
 private String languageMode="auto";

 @Override public void onCreate(){super.onCreate();
  NotificationChannel channel=new NotificationChannel("study","학습 영역 번역",NotificationManager.IMPORTANCE_LOW);
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(metrics);
  width=metrics.widthPixels;height=metrics.heightPixels;density=metrics.densityDpi;
  englishOcr=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  japaneseOcr=TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  Notification n=new Notification.Builder(this,"study").setContentTitle("학습 영역 번역 준비됨")
   .setContentText("번역 버튼을 누른 뒤 영역을 드래그하세요")
   .setSmallIcon(android.R.drawable.ic_menu_crop)
   .setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE)).build();
  if(Build.VERSION.SDK_INT>=29)startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(1,n);
  if(intent==null||!intent.hasExtra("data")){stopSelf();return START_NOT_STICKY;}
  MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
  Intent data=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra("data",Intent.class):intent.getParcelableExtra("data");
  projection=manager.getMediaProjection(intent.getIntExtra("result",-1),data);
  if(projection==null){stopSelf();return START_NOT_STICKY;}
  projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
  reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
  virtualDisplay=projection.createVirtualDisplay("region-translation",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
  showBubble();return START_NOT_STICKY;
 }
 private WindowManager.LayoutParams params(int w,int h,int flags){
  return new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
 }
 private void showBubble(){
  Button b=new Button(this);b.setText("번역 영역 선택");b.setAllCaps(false);
  WindowManager.LayoutParams p=params(-2,-2,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
  p.gravity=Gravity.TOP|Gravity.END;p.y=height/5;
  wm.addView(b,p);bubble=b;
  b.setOnClickListener(v->startSelection());
  b.setOnLongClickListener(v->{stopSelf();return true;});
 }
 private void startSelection(){
  if(busy){Toast.makeText(this,"이전 번역을 처리 중입니다",Toast.LENGTH_SHORT).show();return;}
  removeResult();
  if(bubble!=null)bubble.setVisibility(View.GONE);
  selectionView=new SelectionView(this);
  WindowManager.LayoutParams p=params(-1,-1,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
  p.gravity=Gravity.TOP|Gravity.START;
  wm.addView(selectionView,p);selection=selectionView;
 }
 private class SelectionView extends View {
  Paint paint=new Paint(3);float x0,y0,x1,y1;boolean dragging=false;
  SelectionView(Context c){super(c);setBackgroundColor(0x44000000);}
  @Override protected void onDraw(Canvas c){super.onDraw(c);
   if(!dragging)return;
   RectF r=new RectF(Math.min(x0,x1),Math.min(y0,y1),Math.max(x0,x1),Math.max(y0,y1));
   paint.setColor(0x443399FF);paint.setStyle(Paint.Style.FILL);c.drawRect(r,paint);
   paint.setColor(0xFF1688FF);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(5);c.drawRect(r,paint);paint.setStyle(Paint.Style.FILL);
  }
  @Override public boolean onTouchEvent(android.view.MotionEvent e){
   switch(e.getActionMasked()){
    case MotionEvent.ACTION_DOWN:x0=x1=e.getX();y0=y1=e.getY();dragging=true;invalidate();return true;
    case MotionEvent.ACTION_MOVE:x1=e.getX();y1=e.getY();invalidate();return true;
    case MotionEvent.ACTION_UP:
     x1=e.getX();y1=e.getY();
     Rect region=new Rect((int)Math.min(x0,x1),(int)Math.min(y0,y1),(int)Math.max(x0,x1),(int)Math.max(y0,y1));
     finishSelection(region);return true;
    case MotionEvent.ACTION_CANCEL:cancelSelection();return true;
   }return true;
  }
 }
 private void cancelSelection(){removeSelection();if(bubble!=null)bubble.setVisibility(View.VISIBLE);}
 private void removeSelection(){if(selection!=null){wm.removeView(selection);selection=null;selectionView=null;}}
 private void finishSelection(Rect region){
  removeSelection();if(bubble!=null)bubble.setVisibility(View.GONE);
  region.intersect(0,0,width,height);
  if(region.width()<25||region.height()<20){showResult("영역이 너무 작습니다. 다시 드래그하세요.",region);return;}
  selected=region;busy=true;final int token=++requestId;
  // Keep all overlays hidden while taking the screenshot, so OCR never reads its own status text.
  removeResult();
  // Allow overlay changes to disappear from the screen-capture stream.
  handler.postDelayed(()->captureRegion(token,0),450);
 }
 private void captureRegion(int token,int attempt){
  if(token!=requestId||reader==null)return;
  Image image=reader.acquireLatestImage();
  if(image==null){if(attempt<12)handler.postDelayed(()->captureRegion(token,attempt+1),180);else fail("화면을 가져오지 못했습니다. 다시 선택해 주세요.",token);return;}
  try{
   Image.Plane plane=image.getPlanes()[0];ByteBuffer buffer=plane.getBuffer();
   int rowStride=plane.getRowStride(),pixelStride=plane.getPixelStride();
   int bitmapWidth=rowStride/pixelStride;
   Bitmap full=Bitmap.createBitmap(bitmapWidth,height,Bitmap.Config.ARGB_8888);
   full.copyPixelsFromBuffer(buffer);image.close();
   Bitmap crop=Bitmap.createBitmap(full,selected.left,selected.top,selected.width(),selected.height());full.recycle();
   recognize(crop,token);
  }catch(Exception e){image.close();fail("화면 처리 오류: "+e.getMessage(),token);}
 }
 private void recognize(Bitmap crop,int token){
  InputImage input=InputImage.fromBitmap(crop,0);
  englishOcr.process(input).addOnSuccessListener(en->{
   japaneseOcr.process(input).addOnSuccessListener(ja->{
    crop.recycle();if(token!=requestId)return;
    String english=orderedText(en),japanese=orderedText(ja);
    boolean jp=containsJapanese(japanese) && (!containsJapanese(english) || japanese.length()>=english.length()/2);
    String source=jp?japanese:english;
    if(source.trim().isEmpty())source=jp?english:japanese;
    if(source.trim().isEmpty()){fail("선택한 영역에서 글자를 찾지 못했습니다.",token);return;}
    translate(source,jp,token);
   }).addOnFailureListener(e->{crop.recycle();fail("일본어 문자 인식 오류: "+e.getMessage(),token);});
  }).addOnFailureListener(e->{crop.recycle();fail("영어 문자 인식 오류: "+e.getMessage(),token);});
 }
 private String orderedText(Text result){
  ArrayList<Text.Line> lines=new ArrayList<>();
  for(Text.TextBlock block:result.getTextBlocks())lines.addAll(block.getLines());
  Collections.sort(lines,(a,b)->{Rect x=a.getBoundingBox(),y=b.getBoundingBox();if(x==null||y==null)return 0;
   if(Math.abs(x.centerY()-y.centerY())<Math.max(x.height(),y.height())/2)return Integer.compare(x.left,y.left);
   return Integer.compare(x.top,y.top);
  });
  StringBuilder sb=new StringBuilder();for(Text.Line line:lines){if(sb.length()>0)sb.append(' ');sb.append(line.getText().trim());}
  return sb.toString();
 }
 private boolean containsJapanese(String s){for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c>=0x3040&&c<=0x30ff||c>=0xff66&&c<=0xff9f)return true;}return false;}
 private void translate(String text,boolean japanese,int token){
  showResult("문장 번역 중…\n"+text,selected);
  Translator translator=japanese?japaneseTranslator:englishTranslator;
  if(translator==null){translator=Translation.getClient(new TranslatorOptions.Builder()
   .setSourceLanguage(japanese?TranslateLanguage.JAPANESE:TranslateLanguage.ENGLISH)
   .setTargetLanguage(TranslateLanguage.KOREAN).build());
   if(japanese)japaneseTranslator=translator;else englishTranslator=translator;
  }
  final Translator active=translator;
  showResult("번역 모델 준비 중… (첫 사용 시 다운로드)\n"+text,selected);
  active.downloadModelIfNeeded().addOnSuccessListener(v->{
   if(token!=requestId)return;
   showResult("문장 번역 중…\n"+text,selected);
   active.translate(text).addOnSuccessListener(korean->{if(token==requestId){busy=false;showResult(korean,selected);}})
    .addOnFailureListener(e->fail("번역 실패: "+e.getMessage(),token));
  }).addOnFailureListener(e->fail("번역 모델 다운로드 실패: "+e.getMessage()+"\nWi-Fi를 확인하세요.",token));
 }
 private void fail(String message,int token){if(token==requestId){busy=false;showResult(message,selected);}}
 private void removeResult(){if(resultPanel!=null){wm.removeView(resultPanel);resultPanel=null;}}
 private void showResult(String message,Rect region){handler.post(()->{
  if(bubble!=null)bubble.setVisibility(View.VISIBLE);
  removeResult();
  LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(18,12,18,8);panel.setBackgroundColor(0xF5FFFFFF);
  TextView text=new TextView(this);text.setText(message);text.setTextColor(0xFF17243B);text.setTextSize(16);panel.addView(text);
  Button close=new Button(this);close.setText("닫기");panel.addView(close);
  int popupWidth=Math.min(width-32,(int)(360*getResources().getDisplayMetrics().density));
  WindowManager.LayoutParams p=params(popupWidth,-2,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
  p.gravity=Gravity.TOP|Gravity.START;p.x=Math.max(0,Math.min(width-popupWidth,region.left));
  p.y=region.top>180?Math.max(0,region.top-175):Math.min(height-220,region.bottom+15);
  wm.addView(panel,p);resultPanel=panel;
  close.setOnClickListener(v->removeResult());
 });}
 @Override public void onDestroy(){++requestId;removeResult();removeSelection();if(bubble!=null)wm.removeView(bubble);
  if(virtualDisplay!=null)virtualDisplay.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();
  if(englishOcr!=null)englishOcr.close();if(japaneseOcr!=null)japaneseOcr.close();
  if(englishTranslator!=null)englishTranslator.close();if(japaneseTranslator!=null)japaneseTranslator.close();super.onDestroy();}
 @Override public IBinder onBind(Intent intent){return null;}
}
